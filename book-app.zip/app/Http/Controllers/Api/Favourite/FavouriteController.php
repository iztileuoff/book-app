<?php

namespace App\Http\Controllers\Api\Favourite;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FavouriteController extends Controller
{
    //
}
