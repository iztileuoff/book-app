<?php

namespace App\Http\Controllers\Api\Gener;

use App\Http\Controllers\Controller;
use App\Models\Gener;
use Illuminate\Http\Request;

class GenerController extends Controller
{
    public function index(Request $request)
    {
        $geners = Gener::get();

        return 
    }

    public function store()
    {

    }

    public function show()
    {
        
    }

    public function update()
    {
        
    }

    public function delete()
    {
        
    }
}
