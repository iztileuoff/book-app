<?php

namespace App\Http\Controllers\Api\Basket;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BasketController extends Controller
{
    //
}
